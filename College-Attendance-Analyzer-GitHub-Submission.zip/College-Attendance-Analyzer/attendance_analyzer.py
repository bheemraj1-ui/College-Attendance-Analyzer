"""
College Attendance Analyzer
PS No. 10 | Rungta International Skills University

Reads student attendance from attendance.csv, validates records,
calculates attendance percentages, filters students below 75%,
and plots subject-wise averages.
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ATTENDANCE_FILE = Path(__file__).with_name("attendance.csv")
REQUIRED_ATTENDANCE = 75.0
REQUIRED_COLUMNS = [
    "Name",
    "Subject",
    "Classes_Held",
    "Classes_Attended",
]


def load_attendance(file_path=ATTENDANCE_FILE):
    """Load and validate attendance records from a CSV file."""
    try:
        data = pd.read_csv(file_path)
    except FileNotFoundError:
        print(f"\nError: Could not find '{file_path}'.")
        return pd.DataFrame(columns=REQUIRED_COLUMNS)
    except pd.errors.EmptyDataError:
        print("\nError: The CSV file is empty.")
        return pd.DataFrame(columns=REQUIRED_COLUMNS)
    except Exception as error:
        print(f"\nError while reading the CSV file: {error}")
        return pd.DataFrame(columns=REQUIRED_COLUMNS)

    # Check that all required columns are present.
    missing = [column for column in REQUIRED_COLUMNS if column not in data.columns]
    if missing:
        print("Error: Missing CSV column(s): " + ", ".join(missing))
        return pd.DataFrame(columns=REQUIRED_COLUMNS)

    valid_rows = []
    for row_number, row in data.iterrows():
        name = str(row["Name"]).strip()
        subject = str(row["Subject"]).strip()

        try:
            held = float(row["Classes_Held"])
            attended = float(row["Classes_Attended"])
        except (TypeError, ValueError):
            print(f"Row {row_number + 2} invalid: attendance values must be numbers. Row skipped.")
            continue

        if (
            not name
            or name.lower() == "nan"
            or not subject
            or subject.lower() == "nan"
            or held <= 0
            or attended < 0
            or attended > held
        ):
            print(
                f"Row {row_number + 2} invalid: check name, subject, "
                "classes held and classes attended. Row skipped."
            )
            continue

        valid_rows.append(
            {
                "Name": name,
                "Subject": subject,
                "Classes_Held": held,
                "Classes_Attended": attended,
            }
        )

    clean_data = pd.DataFrame(valid_rows, columns=REQUIRED_COLUMNS)
    if clean_data.empty:
        return clean_data

    clean_data["Attendance_Percentage"] = (
        clean_data["Classes_Attended"] / clean_data["Classes_Held"]
    ) * 100

    return clean_data


def show_attendance_percentages(data):
    """Menu option 1: display each student's attendance percentage."""
    if data.empty:
        print("\nNo valid attendance records are available.")
        return

    print("\nSTUDENT ATTENDANCE PERCENTAGE")
    print("-" * 58)
    print(f"{'Name':<18}{'Subject':<18}{'Attendance':>12}")
    print("-" * 58)

    for _, row in data.iterrows():
        print(
            f"{row['Name']:<18}{row['Subject']:<18}"
            f"{row['Attendance_Percentage']:>10.2f}%"
        )


def show_shortage_list(data):
    """Menu option 2: show students whose attendance is below 75%."""
    if data.empty:
        print("\nNo valid attendance records are available.")
        return

    shortage = data[data["Attendance_Percentage"] < REQUIRED_ATTENDANCE]

    print(f"\nSTUDENTS BELOW {REQUIRED_ATTENDANCE:.0f}% ATTENDANCE")
    print("-" * 58)

    if shortage.empty:
        print("No student is below 75%. All listed records are eligible.")
        return

    print(f"{'Name':<18}{'Subject':<18}{'Attendance':>12}")
    print("-" * 58)
    for _, row in shortage.iterrows():
        print(
            f"{row['Name']:<18}{row['Subject']:<18}"
            f"{row['Attendance_Percentage']:>10.2f}%"
        )


def show_subject_analysis(data):
    """Menu option 3: calculate subject averages and draw bar and pie charts."""
    if data.empty:
        print("\nNo valid attendance records are available.")
        return

    subject_average = (
        data.groupby("Subject")["Attendance_Percentage"]
        .mean()
        .sort_values(ascending=False)
    )

    print("\nSUBJECT-WISE AVERAGE ATTENDANCE")
    print("-" * 42)
    for subject, average in subject_average.items():
        print(f"{subject:<22} {average:.2f}%")

    # Bar chart
    plt.figure(figsize=(8, 5))
    subject_average.plot(kind="bar")
    plt.title("Subject-wise Average Attendance")
    plt.xlabel("Subject")
    plt.ylabel("Average Attendance (%)")
    plt.ylim(0, 100)
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.show()

    # Pie chart
    plt.figure(figsize=(7, 7))
    plt.pie(
        subject_average.values,
        labels=subject_average.index,
        autopct="%1.1f%%",
        startangle=90,
    )
    plt.title("Distribution of Subject-wise Average Attendance")
    plt.tight_layout()
    plt.show()


def main():
    """Run the menu-driven College Attendance Analyzer."""
    print("=" * 54)
    print("          COLLEGE ATTENDANCE ANALYZER")
    print("=" * 54)

    data = load_attendance()
    if data.empty:
        print("\nNo valid records were loaded. Check attendance.csv.")
        return

    print(f"\nSuccessfully loaded {len(data)} valid record(s).")

    while True:
        print("\nMAIN MENU")
        print("1. Display attendance percentage")
        print("2. Display students below 75% attendance")
        print("3. Show subject-wise average and charts")
        print("4. Exit")

        choice = input("Enter your choice (1-4): ").strip()

        if choice == "1":
            show_attendance_percentages(data)
        elif choice == "2":
            show_shortage_list(data)
        elif choice == "3":
            show_subject_analysis(data)
        elif choice == "4":
            print("\nThank you for using College Attendance Analyzer!")
            break
        else:
            print("\nInvalid choice. Please enter 1, 2, 3 or 4.")


if __name__ == "__main__":
    main()
