# College Attendance Analyzer

**Problem Statement No.:** 10  
**Course:** B.Tech Computer Science and Engineering  
**Language:** Python 3

## Project overview

College Attendance Analyzer reads student attendance records from a CSV file, calculates attendance percentages, identifies records below the required 75% attendance, and displays subject-wise average attendance using Matplotlib bar and pie charts.

## Features

1. Reads attendance data using Pandas.
2. Calculates attendance percentage for every valid record.
3. Filters and displays records below 75%.
4. Calculates subject-wise average attendance.
5. Displays a bar chart and a pie chart.
6. Validates records. Invalid rows (for example, attended classes greater than classes held) are skipped with a message.

## Project files

```text
College-Attendance-Analyzer/
├── attendance_analyzer.py
├── attendance.csv
├── requirements.txt
└── README.md
```

## CSV format

The CSV file must contain these exact column headings:

- `Name`
- `Subject`
- `Classes_Held`
- `Classes_Attended`

Example:

```csv
Name,Subject,Classes_Held,Classes_Attended
Aman,Python,40,36
Riya,Python,40,28
Karan,Python,40,30
```

## Attendance formula

`Attendance Percentage = (Classes Attended / Classes Held) * 100`

A record with exactly 75% attendance is eligible. Only records strictly below 75% appear in the shortage list.

## Setup and execution

1. Install Python 3.
2. Open a terminal in this project folder.
3. Install the required libraries:

   ```bash
   pip install -r requirements.txt
   ```

4. Run the program:

   ```bash
   python attendance_analyzer.py
   ```

5. Choose an option from the menu:
   - `1` — Display attendance percentage.
   - `2` — Display students below 75%.
   - `3` — Display subject-wise averages and charts.
   - `4` — Exit.

## Test cases to try

### Test case 1: Normal input

Use the sample `attendance.csv`.

Expected percentages:
- Aman: 90.00%
- Riya: 70.00%
- Karan: 75.00%

Expected shortage list: Riya only.

### Test case 2: Boundary / minimum input

Temporarily keep only this record:

```csv
Name,Subject,Classes_Held,Classes_Attended
Karan,Python,40,30
```

Expected: Karan has 75.00%; no record is below 75%.

### Test case 3: Invalid input

Try:

```csv
Name,Subject,Classes_Held,Classes_Attended
Aman,Python,40,45
```

Expected: the row is reported as invalid and skipped.

### Test case 4: Subject-wise analysis

Try:

```csv
Name,Subject,Classes_Held,Classes_Attended
Aman,Python,40,36
Riya,Python,40,28
Karan,Python,40,30
Aman,Maths,50,45
```

Expected subject averages:
- Python: 78.33%
- Maths: 90.00%

The program displays a bar chart and a pie chart.

## Notes

- Keep `attendance.csv` in the same folder as `attendance_analyzer.py`.
- The sample CSV is editable. Add your own student records using the same column headings.
- The program calculates subject averages from the valid rows present in the CSV.
